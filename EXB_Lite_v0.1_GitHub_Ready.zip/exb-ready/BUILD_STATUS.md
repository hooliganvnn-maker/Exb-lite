# EXB Lite v0.1 Build Status

This package is the GitHub-ready Android project structure.

Current scope: initial UI scaffold and GitHub Actions build pipeline.

Not yet implemented: persistent Room database, secure PIN storage, draft recovery, attachments, search index, status workflow, trash/restore, share/export, backup/restore.

The APK must be built by Android/Gradle tooling; this package is not itself an APK.
