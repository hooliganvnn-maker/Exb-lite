package com.exb.lite

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private data class Record(val id: Long, val content: String, val status: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { EXBLiteApp() }
    }
}

@Composable
private fun EXBLiteApp() {
    var unlocked by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var records by remember { mutableStateOf(emptyList<Record>()) }
    var search by remember { mutableStateOf("") }
    var showNew by remember { mutableStateOf(false) }

    MaterialTheme {
        when {
            !unlocked -> PinScreen(pin, { pin = it }, { if (pin.length >= 4) unlocked = true })
            showNew -> NewRecordScreen(
                content = content,
                onContentChange = { content = it },
                onCancel = { content = ""; showNew = false },
                onSave = {
                    if (content.isNotBlank()) {
                        val nextId = (records.maxOfOrNull { it.id } ?: 0L) + 1L
                        records = records + Record(nextId, content.trim(), "Mới nhập", "Vừa xong")
                        content = ""
                        showNew = false
                    }
                }
            )
            else -> HomeScreen(
                search = search,
                onSearchChange = { search = it },
                records = records,
                onNew = { showNew = true }
            )
        }
    }
}

@Composable
private fun PinScreen(pin: String, onPinChange: (String) -> Unit, onUnlock: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("EXB", style = MaterialTheme.typography.headlineLarge)
        Text("Bộ não bên ngoài", style = MaterialTheme.typography.bodyLarge)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = pin,
            onValueChange = { value ->
                val digits = value.filter(Char::isDigit).take(8)
                onPinChange(digits)
            },
            label = { Text("Mã PIN") },
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        Button(onClick = onUnlock, enabled = pin.length >= 4) { Text("Mở EXB") }
    }
}

@Composable
private fun NewRecordScreen(
    content: String,
    onContentChange: (String) -> Unit,
    onCancel: () -> Unit,
    onSave: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Nhập mới", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = content,
            onValueChange = onContentChange,
            modifier = Modifier.fillMaxWidth().weight(1f),
            placeholder = { Text("Nhập điều bạn muốn ghi...") }
        )
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = onCancel) { Text("Hủy") }
            Button(onClick = onSave, enabled = content.isNotBlank()) { Text("Lưu") }
        }
    }
}

@Composable
private fun HomeScreen(
    search: String,
    onSearchChange: (String) -> Unit,
    records: List<Record>,
    onNew: () -> Unit
) {
    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = onNew) { Text("+") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("EXB", style = MaterialTheme.typography.headlineSmall)
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                placeholder = { Text("Bạn muốn tìm gì?") }
            )
            Spacer(Modifier.height(18.dp))
            Text("🆕 MỚI NHẬP", style = MaterialTheme.typography.titleMedium)
            val filtered = records
                .asReversed()
                .filter { it.content.contains(search, ignoreCase = true) }
                .take(5)
            if (filtered.isEmpty()) {
                Text("Chưa có dữ liệu", Modifier.padding(vertical = 12.dp))
            } else {
                LazyColumn {
                    items(filtered, key = { it.id }) { record ->
                        ListItem(
                            headlineContent = { Text(record.content) },
                            supportingContent = { Text("${record.status} · ${record.time}") }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
