# EXB Lite

EXB Lite is a local-first Android app for quick capture, storage and retrieval.

## Target
- Android 11 (API 30) and above
- Minimum target device profile: 2 GB RAM
- No account, cloud, sync or AI in Lite v0.1

## Build locally
Use JDK 17 and Gradle 8.9+ with Android SDK 35 installed, then run:

```bash
gradle assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions
The repository includes a workflow under `.github/workflows/android.yml` that builds the debug APK and publishes it as a workflow artifact.
